import type { Metadata } from "next";
import "@fontsource-variable/archivo/wdth.css";
import "@fontsource/jetbrains-mono/400.css";
import "@fontsource/jetbrains-mono/500.css";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pranay Gupta · Full Stack AI Developer",
  description: "Full stack developer building reliable backends: Redis, queues, PostgreSQL, graph databases. Projects: Tilt, Strata.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
